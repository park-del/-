#ifndef FORM_H
#define FORM_H

#include <QtGui>
#include "ui_form.h"
#include <stdlib.h>
class Tform : public QDialog
{
    Q_OBJECT

public:
    Tform(QWidget *parent = 0, Qt::WFlags flags = 0);
    ~Tform();

public slots:
    void pushButton1_Clicked();
    void pushButton2_Clicked();
private:
    Ui::Form2 ui;
  
};

#endif // MYQTTEST_H
