#include "myqttest.h"
bool ok_flag; 
int  edit_roomid;
char edit_name[20];
char edit_tel[20];
char edit_renttime[20];
int  edit_rentday;
myQtTest::myQtTest(QWidget *parent, Qt::WFlags flags)
    : QDialog(parent, flags)
{
    ui.setupUi(this);
    
    QObject::connect(ui.pushButton1,SIGNAL(clicked()),this,SLOT(pushButton1_Clicked()));      //查询按钮点击时
    QObject::connect(ui.pushButton5,SIGNAL(clicked()),this,SLOT(pushButton5_Clicked()));      //查询按钮点击时

    QObject::connect(ui.pushButton2,SIGNAL(clicked()),this,SLOT(pushButton2_Clicked()));      //入住按钮点击时
    QObject::connect(ui.pushButton3,SIGNAL(clicked()),this,SLOT(pushButton3_Clicked()));      //退房按钮点击时
    QObject::connect(ui.pushButton4,SIGNAL(clicked()),this,SLOT(pushButton4_Clicked()));      //修改按钮点击时
    
    QObject::connect(ui.radioButton1,SIGNAL(clicked()),this,SLOT(radioButton1_Clicked())); 
    QObject::connect(ui.radioButton2,SIGNAL(clicked()),this,SLOT(radioButton2_Clicked())); 
    QObject::connect(ui.radioButton3,SIGNAL(clicked()),this,SLOT(radioButton3_Clicked()));

    QObject::connect(ui.radioButton4,SIGNAL(clicked()),this,SLOT(radioButton4_Clicked()));
    QObject::connect(ui.radioButton5,SIGNAL(clicked()),this,SLOT(radioButton5_Clicked()));
    QObject::connect(ui.radioButton6,SIGNAL(clicked()),this,SLOT(radioButton6_Clicked())); 

    QObject::connect(ui.radioButton7,SIGNAL(clicked()),this,SLOT(radioButton7_Clicked())); 
    QObject::connect(ui.radioButton8,SIGNAL(clicked()),this,SLOT(radioButton8_Clicked()));


      
    ui.radioButton1->setChecked(true);    //初始时选中的是“客房类型表”
    ui.radioButton4->setChecked(true);    //初始时选中的是“不选择”
    ui.radioButton7->setChecked(true);    //初始时选中的是“升序”
       
    room_select=1; //取值为“1、2、3”，1表示的是“不选择”，2表示的是“已经入住房间”，3表示的是“不选择”
    asc_desc=1;    //取值为1、2，其中1表示的是“升序”，2表示的是降序
    
    flush_tableWidget1("select * from roomtype");
         
         
}
myQtTest::~myQtTest() { } 


void myQtTest::flush_tableWidget1(char *sql)
{
       
//查询使用QStringlist来设置ui设计界面上的tableWidget控件的位置
   sqlite3 *db;
	char *zErrMsg = 0;
	int i,j,index;
	int rc;
   
	char **dbResult;   
	int nRow, nColumn;

   rc=sqlite3_open("data.db", &db);  //打开data.db这个数据库
   if( rc )  printf("打不开数据库。\n");

   sqlite3_get_table(db,sql, &dbResult, &nRow,&nColumn,&zErrMsg);  
	if( rc!=SQLITE_OK )  printf("没有查询到结果。\n");


 
   ui.tableWidget1->setRowCount(nRow);  //设置ui界面的行数
   ui.tableWidget1->setColumnCount(nColumn);
   ui.tableWidget1->setHorizontalHeaderLabels(QStringList()<<"roomname"<<"total"<<"rest"<<"price");

   index=nColumn;
   for(i=0;i<nRow;i++)
        {
    for(j=0;j<nColumn;j++)
          {
       QTableWidgetItem *item = new QTableWidgetItem(dbResult[index]);  
	    ui.tableWidget1->setItem(i, j, item);  
	    index++;
           }        
       }

   sqlite3_close(db);
}


void myQtTest::flush_tableWidget2(char *sql)
{
   sqlite3 *db;
	char *zErrMsg = 0;
	int i,j,index;
	int rc;
   
	char **dbResult;   
	int nRow, nColumn;

   rc=sqlite3_open("data.db", &db);  //打开data.db这个数据库
   if( rc )  printf("打不开数据库。\n");

   sqlite3_get_table(db,sql, &dbResult, &nRow,&nColumn,&zErrMsg);  
	if( rc!=SQLITE_OK )  printf("没有查询到结果。\n");


   
   ui.tableWidget1->setRowCount(nRow);  //设置ui界面的行数
   ui.tableWidget1->setColumnCount(nColumn);
   ui.tableWidget1->setHorizontalHeaderLabels(QStringList()<<"roomid"<<"roomname"<<"isrented");

   index=nColumn;
   for(i=0;i<nRow;i++)
        {
    for(j=0;j<nColumn;j++)
          {
       QTableWidgetItem *item = new QTableWidgetItem(dbResult[index]);  
	    ui.tableWidget1->setItem(i, j, item);  
	    index++;
           }        
       }

   sqlite3_close(db);
}


void myQtTest::flush_tableWidget3(char *sql)
{
   sqlite3 *db;
	char *zErrMsg = 0;
	int i,j,index;
	int rc;
   
	char **dbResult;   
	int nRow, nColumn;

   rc=sqlite3_open("data.db", &db);  //打开data.db这个数据库
   if( rc )  printf("打不开数据库。\n");

   sqlite3_get_table(db,sql, &dbResult, &nRow,&nColumn,&zErrMsg);  
	if( rc!=SQLITE_OK )  printf("没有查询到结果。\n");


   
   ui.tableWidget1->setRowCount(nRow);  //设置ui界面的行数
   ui.tableWidget1->setColumnCount(nColumn);
   ui.tableWidget1->setHorizontalHeaderLabels(QStringList()<<"roomid"<<"name"<<"tel"<<"renttime"<<"rentday");
   
   index=nColumn;
   for(i=0;i<nRow;i++)
        {
    for(j=0;j<nColumn;j++)
          {
       QTableWidgetItem *item = new QTableWidgetItem(dbResult[index]);  
	    ui.tableWidget1->setItem(i, j, item);  
	    index++;
           }        
       }

   sqlite3_close(db);
}


//按钮点击的所触发的槽函数

char *col[2]={"roomid","roomname"};
char *table[3]={"roomtype","roominfo","rentinfo"};


void myQtTest::pushButton1_Clicked()
{
   char sql_str[150];        //定义字符串sql_str
	memset(sql_str,0,150);    //内存清空的操作，对sql_str这个数组的150个空间全部赋值为0
	
   char sql_str1[150];       //定义字符串sql_str
	memset(sql_str1,0,150);

   char sql_str2[150];       //定义字符串sql_str
	memset(sql_str2,0,150);

   char sql_str3[150];       //定义字符串sql_str
	memset(sql_str3,0,150);

   char sql_str4[150];       //定义字符串sql_str
	memset(sql_str4,0,150);


   sprintf(sql_str1,"select * from %s where","roominfo");
   QString s1=ui.lineEdit1->text();
 
   if(s1.length())
      {
      if(ui.comboBox1->currentIndex()==0)
          sprintf(sql_str2,"%s = %d",col[ui.comboBox1->currentIndex()],s1.toInt());
   
      if(ui.comboBox1->currentIndex()==1)
               {
        QByteArray ba = s1.toLatin1();
        sprintf(sql_str2,"%s = '%s'",col[ui.comboBox1->currentIndex()],ba.data()); //单引号要注意
                }
        }

        //上述实现了sql_str1、sql_str2
       
   switch(room_select)
       {
    case 1: sprintf(sql_str3,"");  break;
    case 2: sprintf(sql_str3,"and isrented = 'no'");  break;
    case 3: sprintf(sql_str3,"and isrented = 'is'");  break;
    default: break;
      }      

   switch(asc_desc)
     {
    case 1: sprintf(sql_str4,"order by roomid asc");  break;
    case 2: sprintf(sql_str4,"order by roomid desc");  break;
    default: break;
     }

   sprintf(sql_str,"%s %s %s %s",sql_str1,sql_str2,sql_str3,sql_str4);

        
   QMessageBox::information(this,"Information",sql_str);
   flush_tableWidget2(sql_str);
} 

void myQtTest::pushButton5_Clicked()
{
   char sql_str[150];        //定义字符串sql_str
	memset(sql_str,0,150);    //内存清空的操作，对sql_str这个数组的150个空间全部赋值为0
	
   char sql_str1[150];       //定义字符串sql_str
	memset(sql_str1,0,150);

   char sql_str2[150];       //定义字符串sql_str
	memset(sql_str2,0,150);


   sprintf(sql_str1,"select * from %s where","rentinfo");
   QString s=ui.lineEdit2->text();
   

   if(s.length())
      {
    QByteArray ba = s.toLatin1();
    sprintf(sql_str2,"name = '%s'",ba.data()); //单引号要注意     
       }

      
   sprintf(sql_str,"%s %s ",sql_str1,sql_str2);
   QMessageBox::information(this,"Information",sql_str);

   printf("%s\n",sql_str);
       

//下面是对数据库的操作
   sqlite3 *db;
	char *zErrMsg = 0;
	int i,j,index;
	int rc;
   
	char **dbResult;   
	int nRow, nColumn;

   rc=sqlite3_open("data.db", &db);  //打开data.db这个数据库
   if( rc )  printf("打不开数据库。\n");

   sqlite3_get_table(db,sql_str, &dbResult, &nRow,&nColumn,&zErrMsg);  
	if( rc!=SQLITE_OK )  printf("没有查询到结果。\n");

   index=nColumn;  //由于查询出来的就只有一个元组，故可以不需要有Row的循环
  
   ui.textEdit2->setText("");

    char m[150];       //定义字符串sql_str
	 memset(m,0,150);

    for(j=0;j<nColumn;j++)
          {
                  
       if(j==4)
                   {
         int tt;  
         tt=atoi(dbResult[5]);     //字符串转化为整形
      
         if(tt>100 && tt<200)
                       {
           char str[25]; int num;
           num=atoi(dbResult[index]);
           num=60*num;
           sprintf(str,"%d",num); //整形转换为字符串
           ui.lineEdit3->setText(str);
                        }
                   
         
         if(tt>200 && tt<300)
                       {
           char str[25]; int num;
           num=atoi(dbResult[index]);
           num=120*num;
           sprintf(str,"%d",num); //整形转换为字符串
           ui.lineEdit3->setText(str);
                        }

         
         if(tt>300 && tt<400)
                       {
           char str[25]; int num;
           num=atoi(dbResult[index]);
           num=180*num;
           sprintf(str,"%d",num); //整形转换为字符串
           ui.lineEdit3->setText(str);
                        }

         if(tt>400 && tt<500)
                       {
           char str[25]; int num;
           num=atoi(dbResult[index]);
           num=240*num;
           sprintf(str,"%d",num); //整形转换为字符串
           ui.lineEdit3->setText(str);
                        }


         if(tt>500 && tt<600)
                       {
           char str[25]; int num;
           num=atoi(dbResult[index]);
           num=300*num;
           sprintf(str,"%d",num); //整形转换为字符串
           ui.lineEdit3->setText(str);
                        }

                  }     

       sprintf(m,"%s: %s ",dbResult[j],dbResult[index]);
       ui.textEdit2->append(m);
       ui.textEdit2->append("");
	    index++;
           }        
     
   sqlite3_close(db);
}


void myQtTest::pushButton2_Clicked()
{
   ok_flag=false;
   
   edit_roomid=0;
	memset(edit_name,0,20);
	memset(edit_tel,0,20);
   memset(edit_renttime,0,20);
	edit_rentday=0;


   Tform *dlg=new Tform();
	dlg->exec();   

	if(ok_flag)  //根据点击的是主界面中的“确定”按钮还是“取消”按钮来判断是否要执行这个if语句里面的内容
	{
		   sqlite3 *db;
        	char *zErrMsg = 0;
        	char rc[20];
        	
			sqlite3_open("data.db", &db);  //db指针指向了“data.db”这个数据库
		   char sql_str[100];memset(sql_str,0,100);

                        //修改入住信息表
		   sprintf(sql_str,"insert into %s values(%d,'%s','%s','%s',%d);","rentinfo",edit_roomid,edit_name,edit_tel,edit_renttime,edit_rentday);
		   sqlite3_exec(db,sql_str, 0, 0, &zErrMsg);   
         

                       
         memset(rc,0,20);


         switch(edit_roomid)
                       {
          case 100 ... 199: sprintf(rc,"%s","dan_ren"); break;
          case 200 ... 299: sprintf(rc,"%s","da_chuang"); break;
          case 300 ... 399: sprintf(rc,"%s","shaung_ren"); break;
          case 400 ... 499: sprintf(rc,"%s","san_ren"); break;
          case 500 ... 599: sprintf(rc,"%s","tao_fang"); break;
                       }
         printf("%s\n",rc);
                  
         memset(sql_str,0,100);         //清空ss字符串数组，置为0
         sprintf(sql_str,"update roomtype set rest=rest-1 where roomname = '%s';",rc);   
         sqlite3_exec(db,sql_str, 0, 0, &zErrMsg);   
         printf("客房类型表：%s\n",sql_str);


         memset(sql_str,0,100);         //修改客房信息表
         sprintf(sql_str,"update roominfo set isrented='is' where roomid = %d;",edit_roomid);   
         sqlite3_exec(db,sql_str, 0, 0, &zErrMsg);   
         printf("客房信息表：%s\n",sql_str);
         
     
         ui.radioButton3->setChecked(true);
         flush_tableWidget3("select * from rentinfo;"); //刷新Roomid表
         sqlite3_close(db);
	}


       printf("%d\n",edit_roomid);
       printf("%s\n",edit_name);
       printf("%s\n",edit_tel);
       printf("%s\n",edit_renttime);
       printf("%d\n",edit_rentday);

}

void myQtTest::pushButton3_Clicked()
{
   
	 if(QMessageBox::question(this,"Question",tr("Do you want to delete the current record?"),QMessageBox::Ok|  QMessageBox::Cancel,QMessageBox::Ok)==QMessageBox::Cancel)
	{
		return;
	} 
		   sqlite3 *db;
        	char *zErrMsg = 0;
        	char rc[20];
        	
			sqlite3_open("data.db", &db);  //db指针指向了“data.db”这个数据库
		   char sql_str[100];memset(sql_str,0,100);

         int row=ui.tableWidget1->currentRow(); //row记录ui界面中的tableWidget控件中的当前行
         QTableWidgetItem *item1=ui.tableWidget1->item(row,0);                         
	      QTableWidgetItem *item2=ui.tableWidget1->item(row,1); 
	      QTableWidgetItem *item3=ui.tableWidget1->item(row,2); 
	      QTableWidgetItem *item4=ui.tableWidget1->item(row,3); 
	      QTableWidgetItem *item5=ui.tableWidget1->item(row,4); 
		   
         QString str1=item1->text();
         QString str2=item2->text();
         QString str3=item3->text();
         QString str4=item4->text();
         QString str5=item5->text();

         QByteArray ba2 = str2.toLatin1(); 
         QByteArray ba3 = str3.toLatin1(); 
         QByteArray ba4 = str4.toLatin1(); 

         int roomid_t,rentday_t;
         char name_t[20],tel_t[20],renttime_t[20];

         roomid_t=str1.toInt();
         sprintf(name_t,"%s",ba2.data());
         sprintf(tel_t,"%s",ba3.data());
         sprintf(renttime_t,"%s",ba4.data());
         rentday_t=str5.toInt();


         sprintf(sql_str,"delete from %s where roomid=%d;","rentinfo",roomid_t);
		   sqlite3_exec(db,sql_str, 0, 0, &zErrMsg);   
         
                      
         memset(rc,0,20);
         switch(roomid_t)
                       {
          case 100 ... 199: sprintf(rc,"%s","dan_ren"); break;
          case 200 ... 299: sprintf(rc,"%s","da_chuang"); break;
          case 300 ... 399: sprintf(rc,"%s","shuang_ren"); break;
          case 400 ... 499: sprintf(rc,"%s","san_ren"); break;
          case 500 ... 599: sprintf(rc,"%s","tao_fang"); break;
                       }
         printf("%s\n",rc);
                  
         memset(sql_str,0,100);         //清空ss字符串数组，置为0
         sprintf(sql_str,"update roomtype set rest=rest+1 where roomname = '%s';",rc);   
         sqlite3_exec(db,sql_str, 0, 0, &zErrMsg);   
         printf("客房类型表：%s\n",sql_str);


         memset(sql_str,0,100);         //修改客房信息表
         sprintf(sql_str,"update roominfo set isrented='no' where roomid = %d;",roomid_t);   
         sqlite3_exec(db,sql_str, 0, 0, &zErrMsg);   
         printf("客房信息表：%s\n",sql_str);
         
     
         ui.radioButton3->setChecked(true);
         flush_tableWidget3("select * from rentinfo;"); //刷新Roomid表
         sqlite3_close(db);
	

       printf("%d\n",edit_roomid);
       printf("%s\n",edit_name);
       printf("%s\n",edit_tel);
       printf("%s\n",edit_renttime);
       printf("%d\n",edit_rentday);

}

void myQtTest::pushButton4_Clicked()
{
   ok_flag=false;
   
   edit_roomid=0;
	memset(edit_name,0,20);
	memset(edit_tel,0,20);
   memset(edit_renttime,0,20);
	edit_rentday=0;


   Tform *dlg=new Tform();
	dlg->exec();   

	if(ok_flag)  //根据点击的是主界面中的“确定”按钮还是“取消”按钮来判断是否要执行这个if语句里面的内容
	{
		   sqlite3 *db;
        	char *zErrMsg = 0;
        	char rc[20];
        	
			sqlite3_open("data.db", &db);  //db指针指向了“data.db”这个数据库
		   char sql_str[100];memset(sql_str,0,100);

 
                        //修改入住信息表
		   sprintf(sql_str,"delete from %s where roomid=%d;","rentinfo",edit_roomid);   
		   sqlite3_exec(db,sql_str, 0, 0, &zErrMsg);   
                            

         sprintf(sql_str,"insert into %s values(%d,'%s','%s','%s',%d);","rentinfo",edit_roomid,edit_name,edit_tel,edit_renttime,edit_rentday);
		   sqlite3_exec(db,sql_str, 0, 0, &zErrMsg);   

         ui.radioButton3->setChecked(true);
         flush_tableWidget3("select * from rentinfo;"); //刷新Roomid表
         sqlite3_close(db);
	}


       printf("%d\n",edit_roomid);
       printf("%s\n",edit_name);
       printf("%s\n",edit_tel);
       printf("%s\n",edit_renttime);
       printf("%d\n",edit_rentday);
}





void myQtTest::radioButton1_Clicked()
{
      flush_tableWidget1("select * from roomtype");
      printf("1  被点击了\n");
}

void myQtTest::radioButton2_Clicked()
{
      flush_tableWidget2("select * from roominfo");
      printf("2   被点击了\n");
}

void myQtTest::radioButton3_Clicked()
{
      flush_tableWidget3("select * from rentinfo");
      printf("3  被点击了\n");
}


void myQtTest::radioButton4_Clicked()
{
    room_select=1;
    printf("room_select=1\n");
}

void myQtTest::radioButton5_Clicked()
{
    room_select=2;
    printf("room_select=2\n");
}

void myQtTest::radioButton6_Clicked()
{
     room_select=3;
     printf("room_select=3\n");
}


void myQtTest::radioButton7_Clicked()
{
     asc_desc=1;
     printf("asc_desc=1\n");
}
void myQtTest::radioButton8_Clicked()
{
     asc_desc=2;
     printf("asc_desc=2\n");
}
