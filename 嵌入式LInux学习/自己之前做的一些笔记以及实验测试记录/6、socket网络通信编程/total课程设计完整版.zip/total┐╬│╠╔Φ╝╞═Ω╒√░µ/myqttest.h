#ifndef MYQTTEST_H
#define MYQTTEST_H

#include <QtGui>
#include "ui_myqttest.h"
#include "sqlite3.h"
#include <stdlib.h>
#include <stdio.h>
#include "tform.h"

class myQtTest : public QDialog
{
    Q_OBJECT

public:
    myQtTest(QWidget *parent = 0, Qt::WFlags flags = 0);
    ~myQtTest();

public slots:
   void pushButton1_Clicked();   
   void pushButton5_Clicked();

   void pushButton2_Clicked();
   void pushButton3_Clicked();
   void pushButton4_Clicked();


   void radioButton1_Clicked();
   void radioButton2_Clicked();
   void radioButton3_Clicked();
   void radioButton4_Clicked();
   void radioButton5_Clicked();
   void radioButton6_Clicked();
   void radioButton7_Clicked();
   void radioButton8_Clicked();

   
   void flush_tableWidget1(char *sql);
   void flush_tableWidget2(char *sql);
   void flush_tableWidget3(char *sql); 
private:
    Ui::Form ui;
    int room_select;
    int asc_desc;
};

#endif // MYQTTEST_H
