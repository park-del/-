#include "tform.h"
extern bool ok_flag; 
extern int  edit_roomid;
extern char edit_name[20];
extern char edit_tel[20];
extern char edit_renttime[20];
extern int  edit_rentday;

Tform::Tform(QWidget *parent, Qt::WFlags flags)
    : QDialog(parent, flags)
{
    ui.setupUi(this);
    QObject::connect(ui.pushButton1,SIGNAL(clicked()),this,SLOT(pushButton1_Clicked())); 
    QObject::connect(ui.pushButton2,SIGNAL(clicked()),this,SLOT(pushButton2_Clicked())); 
}
Tform::~Tform() { } 

void Tform::pushButton1_Clicked()
{
    printf("ok按钮被点击了\n");


	QString s1 =  ui.lineEdit1->text();   
   QString s2 =  ui.lineEdit2->text();   
   QString s3 =  ui.lineEdit3->text();   
   QString s4 =  ui.lineEdit4->text();   
   QString s5 =  ui.lineEdit5->text();     

 
   QByteArray ba2 = s2.toLatin1(); 
   QByteArray ba3 = s3.toLatin1(); 
   QByteArray ba4 = s4.toLatin1(); 
 


   edit_roomid=s1.toInt();
   sprintf(edit_name,"%s",ba2.data());
   sprintf(edit_tel,"%s",ba3.data());
   sprintf(edit_renttime,"%s",ba4.data());
   edit_rentday=s5.toInt();

/*  测试结果正确：
   printf("%d\n",edit_roomid);
   printf("%s\n",edit_name);
   printf("%s\n",edit_tel);
   printf("%s\n",edit_renttime);
   printf("%d\n",edit_rentday);
*/
   ok_flag=true;
   close();
       
}

void Tform::pushButton2_Clicked()
{
      printf("cancel按钮被点击了\n。");
      ok_flag=false;
      close();

}
