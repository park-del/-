/********************************************************************************
** Form generated from reading ui file 'form.ui'
**
** Created: Fri Dec 24 00:21:01 2021
**      by: Qt User Interface Compiler version 4.4.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_FORM_H
#define UI_FORM_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHBoxLayout>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Form2
{
public:
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QSpacerItem *horizontalSpacer;
    QLineEdit *lineEdit1;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QSpacerItem *horizontalSpacer_2;
    QLineEdit *lineEdit2;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QSpacerItem *horizontalSpacer_3;
    QLineEdit *lineEdit3;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_4;
    QSpacerItem *horizontalSpacer_4;
    QLineEdit *lineEdit4;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_5;
    QSpacerItem *horizontalSpacer_5;
    QLineEdit *lineEdit5;
    QPushButton *pushButton1;
    QPushButton *pushButton2;

    void setupUi(QWidget *Form)
    {
    if (Form->objectName().isEmpty())
        Form->setObjectName(QString::fromUtf8("Form"));
    Form->resize(318, 328);
    verticalLayoutWidget = new QWidget(Form);
    verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
    verticalLayoutWidget->setGeometry(QRect(10, 9, 191, 311));
    verticalLayout = new QVBoxLayout(verticalLayoutWidget);
    verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
    verticalLayout->setContentsMargins(0, 0, 0, 0);
    horizontalLayout = new QHBoxLayout();
    horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
    label = new QLabel(verticalLayoutWidget);
    label->setObjectName(QString::fromUtf8("label"));

    horizontalLayout->addWidget(label);

    horizontalSpacer = new QSpacerItem(32, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

    horizontalLayout->addItem(horizontalSpacer);

    lineEdit1 = new QLineEdit(verticalLayoutWidget);
    lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));

    horizontalLayout->addWidget(lineEdit1);


    verticalLayout->addLayout(horizontalLayout);

    horizontalLayout_2 = new QHBoxLayout();
    horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
    label_2 = new QLabel(verticalLayoutWidget);
    label_2->setObjectName(QString::fromUtf8("label_2"));

    horizontalLayout_2->addWidget(label_2);

    horizontalSpacer_2 = new QSpacerItem(37, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

    horizontalLayout_2->addItem(horizontalSpacer_2);

    lineEdit2 = new QLineEdit(verticalLayoutWidget);
    lineEdit2->setObjectName(QString::fromUtf8("lineEdit2"));

    horizontalLayout_2->addWidget(lineEdit2);


    verticalLayout->addLayout(horizontalLayout_2);

    horizontalLayout_3 = new QHBoxLayout();
    horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
    label_3 = new QLabel(verticalLayoutWidget);
    label_3->setObjectName(QString::fromUtf8("label_3"));

    horizontalLayout_3->addWidget(label_3);

    horizontalSpacer_3 = new QSpacerItem(57, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

    horizontalLayout_3->addItem(horizontalSpacer_3);

    lineEdit3 = new QLineEdit(verticalLayoutWidget);
    lineEdit3->setObjectName(QString::fromUtf8("lineEdit3"));

    horizontalLayout_3->addWidget(lineEdit3);


    verticalLayout->addLayout(horizontalLayout_3);

    horizontalLayout_4 = new QHBoxLayout();
    horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
    label_4 = new QLabel(verticalLayoutWidget);
    label_4->setObjectName(QString::fromUtf8("label_4"));

    horizontalLayout_4->addWidget(label_4);

    horizontalSpacer_4 = new QSpacerItem(20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

    horizontalLayout_4->addItem(horizontalSpacer_4);

    lineEdit4 = new QLineEdit(verticalLayoutWidget);
    lineEdit4->setObjectName(QString::fromUtf8("lineEdit4"));

    horizontalLayout_4->addWidget(lineEdit4);


    verticalLayout->addLayout(horizontalLayout_4);

    horizontalLayout_5 = new QHBoxLayout();
    horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
    label_5 = new QLabel(verticalLayoutWidget);
    label_5->setObjectName(QString::fromUtf8("label_5"));

    horizontalLayout_5->addWidget(label_5);

    horizontalSpacer_5 = new QSpacerItem(28, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

    horizontalLayout_5->addItem(horizontalSpacer_5);

    lineEdit5 = new QLineEdit(verticalLayoutWidget);
    lineEdit5->setObjectName(QString::fromUtf8("lineEdit5"));

    horizontalLayout_5->addWidget(lineEdit5);


    verticalLayout->addLayout(horizontalLayout_5);

    pushButton1 = new QPushButton(Form);
    pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
    pushButton1->setGeometry(QRect(230, 120, 80, 27));
    pushButton2 = new QPushButton(Form);
    pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
    pushButton2->setGeometry(QRect(230, 180, 80, 27));

    retranslateUi(Form);

    QMetaObject::connectSlotsByName(Form);
    } // setupUi

    void retranslateUi(QWidget *Form)
    {
    Form->setWindowTitle(QApplication::translate("Form", "Form", 0, QApplication::UnicodeUTF8));
    label->setText(QApplication::translate("Form", "roomid", 0, QApplication::UnicodeUTF8));
    label_2->setText(QApplication::translate("Form", "name", 0, QApplication::UnicodeUTF8));
    label_3->setText(QApplication::translate("Form", "tel", 0, QApplication::UnicodeUTF8));
    label_4->setText(QApplication::translate("Form", "renttime", 0, QApplication::UnicodeUTF8));
    label_5->setText(QApplication::translate("Form", "rentday", 0, QApplication::UnicodeUTF8));
    pushButton1->setText(QApplication::translate("Form", "ok", 0, QApplication::UnicodeUTF8));
    pushButton2->setText(QApplication::translate("Form", "cancel", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(Form);
    } // retranslateUi

};

namespace Ui {
    class Form2: public Ui_Form2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORM_H
