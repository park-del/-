/****************************************************************************
** Meta object code from reading C++ file 'tform.h'
**
** Created: Fri Dec 24 00:24:08 2021
**      by: The Qt Meta Object Compiler version 59 (Qt 4.4.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "tform.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'tform.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.4.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_Tform[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // slots: signature, parameters, type, tag, flags
       7,    6,    6,    6, 0x0a,
      29,    6,    6,    6, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_Tform[] = {
    "Tform\0\0pushButton1_Clicked()\0"
    "pushButton2_Clicked()\0"
};

const QMetaObject Tform::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_Tform,
      qt_meta_data_Tform, 0 }
};

const QMetaObject *Tform::metaObject() const
{
    return &staticMetaObject;
}

void *Tform::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Tform))
	return static_cast<void*>(const_cast< Tform*>(this));
    return QDialog::qt_metacast(_clname);
}

int Tform::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: pushButton1_Clicked(); break;
        case 1: pushButton2_Clicked(); break;
        }
        _id -= 2;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
