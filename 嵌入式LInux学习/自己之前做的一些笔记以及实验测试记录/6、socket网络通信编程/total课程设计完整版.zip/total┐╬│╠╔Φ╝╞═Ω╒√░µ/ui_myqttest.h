/********************************************************************************
** Form generated from reading ui file 'myqttest.ui'
**
** Created: Fri Dec 24 09:43:50 2021
**      by: Qt User Interface Compiler version 4.4.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_MYQTTEST_H
#define UI_MYQTTEST_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTableWidget>
#include <QtGui/QTextEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Form
{
public:
    QTableWidget *tableWidget1;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_2;
    QGroupBox *groupBox;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QRadioButton *radioButton1;
    QRadioButton *radioButton2;
    QRadioButton *radioButton3;
    QGroupBox *groupBox_3;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_2;
    QPushButton *pushButton2;
    QPushButton *pushButton3;
    QPushButton *pushButton4;
    QGroupBox *groupBox_2;
    QVBoxLayout *verticalLayout_5;
    QComboBox *comboBox1;
    QLabel *label_4;
    QLineEdit *lineEdit1;
    QSpacerItem *verticalSpacer;
    QGroupBox *groupBox_6;
    QVBoxLayout *verticalLayout_4;
    QRadioButton *radioButton4;
    QRadioButton *radioButton5;
    QRadioButton *radioButton6;
    QSpacerItem *verticalSpacer_2;
    QGroupBox *groupBox_5;
    QVBoxLayout *verticalLayout_3;
    QRadioButton *radioButton7;
    QRadioButton *radioButton8;
    QSpacerItem *verticalSpacer_3;
    QPushButton *pushButton1;
    QGroupBox *groupBox_4;
    QLabel *label;
    QTextEdit *textEdit;
    QLabel *label_2;
    QLineEdit *lineEdit2;
    QPushButton *pushButton5;
    QLabel *label_6;
    QLineEdit *lineEdit3;
    QTextEdit *textEdit2;

    void setupUi(QWidget *Form)
    {
    if (Form->objectName().isEmpty())
        Form->setObjectName(QString::fromUtf8("Form"));
    Form->resize(1137, 541);
    tableWidget1 = new QTableWidget(Form);
    if (tableWidget1->columnCount() < 4)
        tableWidget1->setColumnCount(4);
    QTableWidgetItem *__colItem = new QTableWidgetItem();
    tableWidget1->setHorizontalHeaderItem(0, __colItem);
    QTableWidgetItem *__colItem1 = new QTableWidgetItem();
    tableWidget1->setHorizontalHeaderItem(1, __colItem1);
    QTableWidgetItem *__colItem2 = new QTableWidgetItem();
    tableWidget1->setHorizontalHeaderItem(2, __colItem2);
    QTableWidgetItem *__colItem3 = new QTableWidgetItem();
    tableWidget1->setHorizontalHeaderItem(3, __colItem3);
    if (tableWidget1->rowCount() < 8)
        tableWidget1->setRowCount(8);
    tableWidget1->setObjectName(QString::fromUtf8("tableWidget1"));
    tableWidget1->setGeometry(QRect(20, 20, 441, 271));
    layoutWidget = new QWidget(Form);
    layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
    layoutWidget->setGeometry(QRect(20, 310, 441, 211));
    horizontalLayout_2 = new QHBoxLayout(layoutWidget);
    horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
    horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
    groupBox = new QGroupBox(layoutWidget);
    groupBox->setObjectName(QString::fromUtf8("groupBox"));
    verticalLayoutWidget = new QWidget(groupBox);
    verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
    verticalLayoutWidget->setGeometry(QRect(0, 20, 141, 151));
    verticalLayout = new QVBoxLayout(verticalLayoutWidget);
    verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
    verticalLayout->setContentsMargins(0, 0, 0, 0);
    radioButton1 = new QRadioButton(verticalLayoutWidget);
    radioButton1->setObjectName(QString::fromUtf8("radioButton1"));

    verticalLayout->addWidget(radioButton1);

    radioButton2 = new QRadioButton(verticalLayoutWidget);
    radioButton2->setObjectName(QString::fromUtf8("radioButton2"));

    verticalLayout->addWidget(radioButton2);

    radioButton3 = new QRadioButton(verticalLayoutWidget);
    radioButton3->setObjectName(QString::fromUtf8("radioButton3"));

    verticalLayout->addWidget(radioButton3);


    horizontalLayout_2->addWidget(groupBox);

    groupBox_3 = new QGroupBox(layoutWidget);
    groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
    verticalLayoutWidget_2 = new QWidget(groupBox_3);
    verticalLayoutWidget_2->setObjectName(QString::fromUtf8("verticalLayoutWidget_2"));
    verticalLayoutWidget_2->setGeometry(QRect(10, 30, 91, 131));
    verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget_2);
    verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
    verticalLayout_2->setContentsMargins(0, 0, 0, 0);
    pushButton2 = new QPushButton(verticalLayoutWidget_2);
    pushButton2->setObjectName(QString::fromUtf8("pushButton2"));

    verticalLayout_2->addWidget(pushButton2);

    pushButton3 = new QPushButton(verticalLayoutWidget_2);
    pushButton3->setObjectName(QString::fromUtf8("pushButton3"));

    verticalLayout_2->addWidget(pushButton3);

    pushButton4 = new QPushButton(verticalLayoutWidget_2);
    pushButton4->setObjectName(QString::fromUtf8("pushButton4"));

    verticalLayout_2->addWidget(pushButton4);


    horizontalLayout_2->addWidget(groupBox_3);

    groupBox_2 = new QGroupBox(Form);
    groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
    groupBox_2->setGeometry(QRect(490, 10, 231, 521));
    verticalLayout_5 = new QVBoxLayout(groupBox_2);
    verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
    comboBox1 = new QComboBox(groupBox_2);
    comboBox1->setObjectName(QString::fromUtf8("comboBox1"));

    verticalLayout_5->addWidget(comboBox1);

    label_4 = new QLabel(groupBox_2);
    label_4->setObjectName(QString::fromUtf8("label_4"));

    verticalLayout_5->addWidget(label_4);

    lineEdit1 = new QLineEdit(groupBox_2);
    lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));

    verticalLayout_5->addWidget(lineEdit1);

    verticalSpacer = new QSpacerItem(20, 39, QSizePolicy::Minimum, QSizePolicy::Expanding);

    verticalLayout_5->addItem(verticalSpacer);

    groupBox_6 = new QGroupBox(groupBox_2);
    groupBox_6->setObjectName(QString::fromUtf8("groupBox_6"));
    verticalLayout_4 = new QVBoxLayout(groupBox_6);
    verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
    radioButton4 = new QRadioButton(groupBox_6);
    radioButton4->setObjectName(QString::fromUtf8("radioButton4"));

    verticalLayout_4->addWidget(radioButton4);

    radioButton5 = new QRadioButton(groupBox_6);
    radioButton5->setObjectName(QString::fromUtf8("radioButton5"));

    verticalLayout_4->addWidget(radioButton5);

    radioButton6 = new QRadioButton(groupBox_6);
    radioButton6->setObjectName(QString::fromUtf8("radioButton6"));

    verticalLayout_4->addWidget(radioButton6);

    radioButton5->raise();
    radioButton6->raise();
    radioButton4->raise();
    radioButton5->raise();
    radioButton6->raise();
    radioButton4->raise();

    verticalLayout_5->addWidget(groupBox_6);

    verticalSpacer_2 = new QSpacerItem(20, 38, QSizePolicy::Minimum, QSizePolicy::Expanding);

    verticalLayout_5->addItem(verticalSpacer_2);

    groupBox_5 = new QGroupBox(groupBox_2);
    groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
    verticalLayout_3 = new QVBoxLayout(groupBox_5);
    verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
    radioButton7 = new QRadioButton(groupBox_5);
    radioButton7->setObjectName(QString::fromUtf8("radioButton7"));

    verticalLayout_3->addWidget(radioButton7);

    radioButton8 = new QRadioButton(groupBox_5);
    radioButton8->setObjectName(QString::fromUtf8("radioButton8"));

    verticalLayout_3->addWidget(radioButton8);

    radioButton8->raise();
    radioButton7->raise();
    radioButton7->raise();
    radioButton8->raise();

    verticalLayout_5->addWidget(groupBox_5);

    verticalSpacer_3 = new QSpacerItem(20, 39, QSizePolicy::Minimum, QSizePolicy::Expanding);

    verticalLayout_5->addItem(verticalSpacer_3);

    pushButton1 = new QPushButton(groupBox_2);
    pushButton1->setObjectName(QString::fromUtf8("pushButton1"));

    verticalLayout_5->addWidget(pushButton1);

    groupBox_4 = new QGroupBox(Form);
    groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
    groupBox_4->setGeometry(QRect(739, 11, 364, 519));
    label = new QLabel(groupBox_4);
    label->setObjectName(QString::fromUtf8("label"));
    label->setGeometry(QRect(11, 28, 60, 18));
    textEdit = new QTextEdit(groupBox_4);
    textEdit->setObjectName(QString::fromUtf8("textEdit"));
    textEdit->setGeometry(QRect(11, 52, 256, 192));
    label_2 = new QLabel(groupBox_4);
    label_2->setObjectName(QString::fromUtf8("label_2"));
    label_2->setGeometry(QRect(11, 250, 60, 27));
    lineEdit2 = new QLineEdit(groupBox_4);
    lineEdit2->setObjectName(QString::fromUtf8("lineEdit2"));
    lineEdit2->setGeometry(QRect(77, 250, 190, 27));
    pushButton5 = new QPushButton(groupBox_4);
    pushButton5->setObjectName(QString::fromUtf8("pushButton5"));
    pushButton5->setGeometry(QRect(273, 250, 80, 27));
    label_6 = new QLabel(groupBox_4);
    label_6->setObjectName(QString::fromUtf8("label_6"));
    label_6->setGeometry(QRect(11, 283, 60, 27));
    lineEdit3 = new QLineEdit(groupBox_4);
    lineEdit3->setObjectName(QString::fromUtf8("lineEdit3"));
    lineEdit3->setGeometry(QRect(77, 283, 190, 27));
    textEdit2 = new QTextEdit(groupBox_4);
    textEdit2->setObjectName(QString::fromUtf8("textEdit2"));
    textEdit2->setGeometry(QRect(11, 316, 342, 192));

    retranslateUi(Form);

    QMetaObject::connectSlotsByName(Form);
    } // setupUi

    void retranslateUi(QWidget *Form)
    {
    Form->setWindowTitle(QApplication::translate("Form", "Form", 0, QApplication::UnicodeUTF8));
    tableWidget1->horizontalHeaderItem(0)->setText(QApplication::translate("Form", "\346\210\277\351\227\264\345\220\215", 0, QApplication::UnicodeUTF8));
    tableWidget1->horizontalHeaderItem(1)->setText(QApplication::translate("Form", "\346\210\277\351\227\264\346\200\273\346\225\260", 0, QApplication::UnicodeUTF8));
    tableWidget1->horizontalHeaderItem(2)->setText(QApplication::translate("Form", "\345\211\251\344\275\231\346\210\277\351\227\264\346\225\260", 0, QApplication::UnicodeUTF8));
    tableWidget1->horizontalHeaderItem(3)->setText(QApplication::translate("Form", "\344\273\267\346\240\274", 0, QApplication::UnicodeUTF8));
    groupBox->setTitle(QApplication::translate("Form", "\350\241\250\345\215\225", 0, QApplication::UnicodeUTF8));
    radioButton1->setText(QApplication::translate("Form", "\345\256\242\346\210\277\347\261\273\345\236\213\350\241\250", 0, QApplication::UnicodeUTF8));
    radioButton2->setText(QApplication::translate("Form", "\345\256\242\346\210\277\344\277\241\346\201\257\350\241\250", 0, QApplication::UnicodeUTF8));
    radioButton3->setText(QApplication::translate("Form", "\345\205\245\344\270\273\344\277\241\346\201\257\350\241\250", 0, QApplication::UnicodeUTF8));
    groupBox_3->setTitle(QApplication::translate("Form", "\346\223\215\344\275\234", 0, QApplication::UnicodeUTF8));
    pushButton2->setText(QApplication::translate("Form", "\345\205\245\344\275\217", 0, QApplication::UnicodeUTF8));
    pushButton3->setText(QApplication::translate("Form", "\351\200\200\346\210\277", 0, QApplication::UnicodeUTF8));
    pushButton4->setText(QApplication::translate("Form", "\344\277\256\346\224\271", 0, QApplication::UnicodeUTF8));
    groupBox_2->setTitle(QApplication::translate("Form", "  \350\277\207\346\273\244\346\237\245\350\257\242", 0, QApplication::UnicodeUTF8));
    comboBox1->insertItems(0, QStringList()
     << QApplication::translate("Form", "\346\210\277\351\227\264\345\217\267", 0, QApplication::UnicodeUTF8)
     << QApplication::translate("Form", "\346\210\277\351\227\264\345\220\215", 0, QApplication::UnicodeUTF8)
    );
    label_4->setText(QApplication::translate("Form", "=", 0, QApplication::UnicodeUTF8));
    groupBox_6->setTitle(QApplication::translate("Form", "\346\237\245\350\257\242\347\251\272\357\274\217\345\267\262\345\205\245\344\275\217\346\210\277\351\227\264:", 0, QApplication::UnicodeUTF8));
    radioButton4->setText(QApplication::translate("Form", "\344\270\215\351\200\211\346\213\251", 0, QApplication::UnicodeUTF8));
    radioButton5->setText(QApplication::translate("Form", "\347\251\272\346\210\277\351\227\264", 0, QApplication::UnicodeUTF8));
    radioButton6->setText(QApplication::translate("Form", "\345\267\262\347\273\217\345\205\245\344\275\217\346\210\277\351\227\264", 0, QApplication::UnicodeUTF8));
    groupBox_5->setTitle(QApplication::translate("Form", "\346\210\277\351\227\264\345\217\267", 0, QApplication::UnicodeUTF8));
    radioButton7->setText(QApplication::translate("Form", "\345\215\207\345\272\217", 0, QApplication::UnicodeUTF8));
    radioButton8->setText(QApplication::translate("Form", "\351\231\215\345\272\217", 0, QApplication::UnicodeUTF8));
    pushButton1->setText(QApplication::translate("Form", "\346\237\245\350\257\242", 0, QApplication::UnicodeUTF8));
    groupBox_4->setTitle(QApplication::translate("Form", "\346\224\266\350\264\271", 0, QApplication::UnicodeUTF8));
    label->setText(QApplication::translate("Form", "\344\273\267\346\240\274\357\274\232", 0, QApplication::UnicodeUTF8));
    textEdit->setHtml(QApplication::translate("Form", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\345\215\225\344\272\272\351\227\264\357\274\23260\345\205\203  \357\274\217\345\244\251</p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\345\244\247\345\272\212\346\210\277\357\274\232120\345\205\203\357\274\217\345\244\251</p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-ri"
        "ght:0px; -qt-block-indent:0; text-indent:0px;\"></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\345\217\214\344\272\272\351\227\264\357\274\232180\345\205\203\357\274\217\345\244\251</p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\344\270\211\344\272\272\351\227\264\357\274\232240\345\205\203\357\274\217\345\244\251</p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\345\245\227\346\210\277  \357\274\232300\345\205\203\357\274\217\345\244\251</p></body></html>", 0, QApplication::UnicodeUTF8));
    label_2->setText(QApplication::translate("Form", "\346\237\245\350\257\242\347\224\250\346\210\267\357\274\232", 0, QApplication::UnicodeUTF8));
    pushButton5->setText(QApplication::translate("Form", "\346\237\245\350\257\242\346\224\266\350\264\271", 0, QApplication::UnicodeUTF8));
    label_6->setText(QApplication::translate("Form", "\345\272\224\347\274\264\350\264\271 \357\274\232", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(Form);
    } // retranslateUi

};

namespace Ui {
    class Form: public Ui_Form {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MYQTTEST_H
